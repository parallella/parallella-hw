
DATA FOR PCB:  9523EE01E

PCB Part Number:  9523EE01     Revision:  E
Zip Filename:  ART_9523EE01E.zip
Layout Contact:  Robbin Wilson
Phone: 336-662-4428 or 336-880-9399    E-Mail:  robbin.wilson@analog.com
Engineering Contact:  Roger Huntley
Phone: 336-662-4349     E-Mail:  roger.huntley@analog.com
Date:  09/01/2010

=============================================================================
Zip File Contains:
=============================================================================
spt    = top paste layer
sst    = top silk layer
smt    = top solder mask layer
top    = metal layer 1
l02    = metal layer 2
l03    = metal layer 3
l04    = metal layer 4
l05    = metal layer 5
bottom = metal layer 6
smb    = bottom solder mask layer
ssb    = bottom silk layer
spb    = bottom silk layer


9523ee01e-1-6.drl            = ascii drill file
9523ee01e.ipc                = IPC-D-356 test file
FAB_9523ee01e.PDF            = Fabrication Drawing
ASY_9523ee01e.pdf          = Assembly Drawing
BOM_9523ee01e.xls                = Bill of Material

README  = This file

